package gachi;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.*;

public class g {
	
	static JPanel p;
	static JFrame f;
	static JButton s;
	JButton sm;
	static Font nf = new Font("Arial", Font.PLAIN, 32);
	static Font nf2 = new Font("Arial", Font.PLAIN, 20);
	static Font nf3 = new Font("Arial", Font.PLAIN, 16);
	static int smhp = 50;
	static int mwhp = 150;
	static int vdhp = 300;
	static int bhhp = 900;
	static int sahp = 1500;
	static int balance = 0;
	
	final int shp = 20;
	

	public static void main(String[] args) throws IOException {
		BufferedImage ic = ImageIO.read(new File("D:/assets/icon.jpg"));
		
		JFrame f = new JFrame("GACHIMUCHI CLICKER");
		f.setSize(800, 600);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.getContentPane().setBackground(Color.black);
		f.setLayout(null);
		f.setIconImage(ic);
		f.setVisible(true);
		
		JLabel lbl = new JLabel("Sigma Games Presents");
		lbl.setFont(nf);
		lbl.setBounds(200, 200, 400, 100);
		lbl.setForeground(Color.white);
		
		
		JButton bs = new JButton("Skip");
		bs.setFocusable(false);
		bs.setBorderPainted(false);
		bs.setBounds(600, 450, 100, 50);
		
		f.add(lbl);
		f.add(bs);
		
		JPanel p = new JPanel();
		p.setBounds(150, 50, 500, 50);
		p.setBackground(Color.black);
		p.setVisible(false);
		
		JLabel l = new JLabel("GACHIMUCHI CLICKER");
		l.setFont(nf);
		l.setBackground(Color.black);
		l.setForeground(Color.white);
		l.setBounds(100, 100, 500, 100);
		l.setVisible(false);
		
		
		JButton s = new JButton("START");
		s.setFont(nf);
		s.setBounds(300, 400, 200, 100);
		s.setFocusable(false);
		s.setVisible(false);
		
		
		BufferedImage b = ImageIO.read(new File("D:/assets/fire.jpg"));
		ImageIcon b1 = new ImageIcon(b);
		JLabel lb = new JLabel(new ImageIcon(b));
		lb.setBounds(0, 0, 800, 600);
		lb.setVisible(false);
	
		f.add(s);
		f.add(p);
		f.add(lb);
		
		p.add(l);
		
		JPanel sts = new JPanel();
		sts.setBounds(100, 100, 600, 300);
		sts.setBackground(Color.black);
		
		JTextArea tfs = new JTextArea();
		tfs.setFont(nf);
		tfs.setBounds(100, 100, 600, 300);
		tfs.setText("������ ��������� ��� ���������� �� \n������� ������: ����. ������������ � ��������� DUNGEON, �� ��������� \n��������� MASTERS, ������� ����� \n��������.");
		tfs.setLineWrap(true);
		tfs.setEditable(false);
		tfs.setBackground(Color.black);
		tfs.setForeground(Color.white);
		
		JButton st = new JButton("������ FISTING");
		st.setFont(nf2);
		st.setFocusable(false);
		st.setBounds(300, 400, 200, 100);
		
		JPanel p1 = new JPanel();
		p1.setBounds(150, 20, 400, 50);
		JLabel l1 = new JLabel("LEVEL 1: Strong Man");
		l1.setFont(nf);
		p1.setBackground(Color.black);
		l1.setForeground(Color.white);
		l1.setBounds(150, 50, 400, 30);
		
		
		JPanel p11 = new JPanel();
		p11.setBounds(150, 450, 900, 50);
		p11.setBackground(Color.black);
		JTextArea t22 = new JTextArea();
		t22.setForeground(Color.white);
		t22.setEditable(false);
		t22.setBounds(150, 450, 900, 50);
		t22.setFont(nf2);
		t22.setText("����: 1");
		t22.setBackground(Color.black);
		p11.add(t22);
		
		JPanel p12 = new JPanel();
		p12.setBounds(0, 500, 100, 50);
		p12.setBackground(Color.black);
		JTextArea t23 = new JTextArea();
		t23.setForeground(Color.white);
		t23.setEditable(false);
		t23.setBounds(0, 500, 100, 50);
		t23.setFont(nf2);
		t23.setText("����: 2");
		t23.setBackground(Color.black);
		p12.add(t23);
		
		JPanel p13 = new JPanel();
		p13.setBounds(0, 500, 100, 50);
		p13.setBackground(Color.black);
		JTextArea t24 = new JTextArea();
		t24.setForeground(Color.white);
		t24.setEditable(false);
		t24.setBounds(0, 500, 100, 50);
		t24.setFont(nf2);
		t24.setText("����: 3");
		t24.setBackground(Color.black);
		p13.add(t24);
		
		JPanel p14 = new JPanel();
		p14.setBounds(0, 450, 100, 50);
		p14.setBackground(Color.black);
		JTextArea t25 = new JTextArea();
		t25.setForeground(Color.white);
		t25.setEditable(false);
		t25.setBounds(0, 450, 100, 50);
		t25.setFont(nf2);
		t25.setText("����: 6");
		t25.setBackground(Color.black);
		p14.add(t25);
		
		JPanel p15 = new JPanel();
		p15.setBounds(0, 450, 100, 50);
		p15.setBackground(Color.black);
		JTextArea t26 = new JTextArea();
		t26.setForeground(Color.white);
		t26.setEditable(false);
		t26.setBounds(0, 450, 100, 50);
		t26.setFont(nf2);
		t26.setText("����: 10");
		t26.setBackground(Color.black);
		p15.add(t26);
		
		JButton sm = new JButton();
		sm.setBounds(150, 100, 500, 300);
		sm.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
		BufferedImage smi = ImageIO.read(new File("D:/assets/strong.png"));
		ImageIcon smi1 = new ImageIcon(smi);
		sm.setIcon(smi1);
		
		JPanel p2 = new JPanel();
		p2.setBounds(150, 400, 600, 50);
		p2.setBackground(Color.black);
		JTextArea t2 = new JTextArea();
		t2.setForeground(Color.white);
		t2.setEditable(false);
		t2.setBounds(150, 400, 600, 50);
		t2.setFont(nf2);
		t2.setText("HP: " + smhp);
		t2.setBackground(Color.black);
		
		JButton smb = new JButton(">");
		smb.setBounds(600, 500, 100, 50);
		smb.setFocusable(false);
		f.add(smb);
		smb.setVisible(false);
		
		JButton mwb = new JButton(">");
		mwb.setBounds(600, 500, 100, 50);
		mwb.setFocusable(false);
		f.add(mwb);
		mwb.setVisible(false);
		
		JButton vdb = new JButton(">");
		vdb.setBounds(600, 500, 100, 50);
		vdb.setFocusable(false);
		f.add(vdb);
		vdb.setVisible(false);
		
		JButton bhb = new JButton(">");
		bhb.setBounds(600, 500, 100, 50);
		bhb.setFocusable(false);
		f.add(bhb);
		bhb.setVisible(false);
		
		JButton sab = new JButton(">");
		sab.setBounds(600, 500, 100, 50);
		sab.setFocusable(false);
		f.add(sab);
		sab.setVisible(false);
		
		BufferedImage mwi = ImageIO.read(new File("D:/assets/mark.jpg"));
		ImageIcon mwi1 = new ImageIcon(mwi);
		JButton mw = new JButton();
		mw.setBounds(150, 100, 400, 400);
		mw.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
		mw.setIcon(mwi1);
		
		JPanel mwh = new JPanel();
		mwh.setBounds(150, 500, 300, 50);
		mwh.setBackground(Color.black);
		JTextArea mwhh = new JTextArea();
		mwhh.setBounds(150, 500, 300, 50);
		mwhh.setForeground(Color.white);
		mwhh.setText("HP: " + mwhp);
		mwhh.setFont(nf2);
		mwhh.setEditable(false);
		mwhh.setBackground(Color.black);
		mwh.setVisible(false);
		
		BufferedImage vdi = ImageIO.read(new File("D:/assets/van.jpg"));
		ImageIcon vdi1 = new ImageIcon(vdi);
		JButton vd = new JButton();
		vd.setBounds(150, 100, 600, 400);
		vd.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
		vd.setIcon(vdi1);
		
		JPanel vdh = new JPanel();
		vdh.setBounds(150, 500, 300, 50);
		vdh.setBackground(Color.black);
		JTextArea vdhh = new JTextArea();
		vdhh.setBounds(150, 500, 300, 50);
		vdhh.setForeground(Color.white);
		vdhh.setText("HP: " + vdhp);
		vdhh.setFont(nf2);
		vdhh.setEditable(false);
		vdhh.setBackground(Color.black);
		vdh.setVisible(false);
		vdh.add(vdhh);
		
		BufferedImage bhi = ImageIO.read(new File("D:/assets/billy.jpg"));
		ImageIcon bhi1 = new ImageIcon(bhi);
		JButton bh = new JButton();
		bh.setBounds(150, 100, 600, 400);
		bh.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
		bh.setIcon(bhi1);
		
		JPanel bhh = new JPanel();
		bhh.setBounds(50, 500, 500, 50);
		bhh.setBackground(Color.black);
		JTextArea bhhh = new JTextArea();
		bhhh.setBounds(50, 500, 500, 50);
		bhhh.setForeground(Color.white);
		bhhh.setText("HP: " + bhhp);
		bhhh.setFont(nf2);
		bhhh.setEditable(false);
		bhhh.setBackground(Color.black);
		bhh.setVisible(false);
		bhh.add(bhhh);
		
		BufferedImage sai = ImageIO.read(new File("D:/assets/sigma.jpg"));
		ImageIcon sai1 = new ImageIcon(sai);
		JButton sa = new JButton();
		sa.setBounds(150, 100, 400, 400);
		sa.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
		sa.setIcon(sai1);
		
		JPanel sah = new JPanel();
		sah.setBounds(50, 500, 500, 50);
		sah.setBackground(Color.black);
		JTextArea sahh = new JTextArea();
		sahh.setBounds(50, 500, 500, 50);
		sahh.setForeground(Color.white);
		sahh.setText("HP: " + sahp);
		sahh.setFont(nf2);
		sahh.setEditable(false);
		sahh.setBackground(Color.black);
		sah.setVisible(false);
		sah.add(sahh);
		
		JPanel ftp = new JPanel();
		ftp.setBounds(50, 50, 500, 500);
		ftp.setBackground(Color.black);
		JTextArea ft = new JTextArea();
		ft.setBounds(50, 50, 500, 300);
		ft.setForeground(Color.white);
		ft.setText("������� Sigma(Alpha), �� ����� ���������� \nDUNGEON MASTER. ������ �� BOSS OF THIS GYM! ����������!!! ������ ����������� THREE \nHUNDRED BUCKS!!!");
		ft.setFont(nf2);
		ft.setLineWrap(true);
		ft.setEditable(false);
		ft.setBackground(Color.black);
		ftp.add(ft);
		
		int balance = 0;
		JPanel balp = new JPanel();
		balp.setBounds(100, 450, 500, 100);
		balp.setBackground(Color.black);
		JLabel bal = new JLabel();
		bal.setBounds(100, 450, 400, 100);
		bal.setText("��� ������: " + balance);
		bal.setBackground(Color.black);
		bal.setForeground(Color.white);
		bal.setFont(nf2);
		balp.add(bal);
		
		JButton balb = new JButton("��������");
		balb.setBounds(300, 250, 200, 100);
		balb.setFocusable(false);
		
		bs.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
			
				lbl.setVisible(false);
				bs.setVisible(false);
				
				p.setVisible(true);
				l.setVisible(true);
				s.setVisible(true);
				lb.setVisible(true);
			}
			
		});
		
		s.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				
				s.setVisible(false);
				p.setVisible(false);
				
				lb.setVisible(false);
			    sts.add(tfs);
			    f.add(st);
			    f.add(sts);
			  
			}
			
			
		});
		st.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				st.setVisible(false);
				sts.setVisible(false);
				f.add(p1);
				p1.add(l1);
				f.add(sm);
				f.add(p11);
				p2.add(t2);
				f.add(p2);
			}
			
		});
		sm.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				smhp = smhp -= 1;
				t2.setText("HP: " + smhp);
				if(smhp == 0){
					t2.setText("�� �������. ������ ��� ���� � ������ ������.");
					smb.setVisible(true);
				}
				
				
			}
			
		});
		smb.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				sm.setVisible(false);
				p11.setVisible(false);
				p2.setVisible(false);
				t2.setVisible(false);
				smb.setVisible(false);
				mwh.add(mwhh);
				f.add(mwh);
				f.add(mw);
				f.add(p12);
				mw.setVisible(true);
				mwh.setVisible(true);
				l1.setText("LEVEL 2: Mark Wolff");
			}
			
		});
		mw.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				mwhp -= 2;
				mwhh.setText("HP: " + mwhp);
				if(mwhp == 0){
					mwhh.setText("�� � FISTING �� ��� �������!");
					mwb.setVisible(true);
					p12.setVisible(false);
				}
				
			}
			
		});
		mwb.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				mw.setVisible(false);
				mwh.setVisible(false);
				mwb.setVisible(false);
				vdh.add(vdhh);
				f.add(vdh);
				f.add(vd);
				vd.setVisible(true);
				vdh.setVisible(true);
				f.add(p13);
				l1.setText("LEVEL 3: Van Darkholme");
			}
			
		});
		vd.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				vdhp -= 3;
				vdhh.setText("HP: " + vdhp);
				if(vdhp == 0){
					vdhh.setText("� �� ������, FUCKING SLAVE!");
					vdb.setVisible(true);
					p13.setVisible(false);
				}
				
			}
			
		});
		vdb.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				vd.setVisible(false);
				vdh.setVisible(false);
				vdb.setVisible(false);
				bhh.add(bhhh);
				f.add(bhh);
				f.add(bh);
				f.add(p14);
				bh.setVisible(true);
				bhh.setVisible(true);
				l1.setText("LEVEL 4: Billy Herrington");
			}
			
		});
		bh.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				bhhp -= 6;
				bhhh.setText("HP: " + bhhp);
				if(bhhp == 0){
					bhhh.setFont(nf3);
					bhhh.setText("�� �� ����� THREE HUNDRED BUCKS ������ �� ������!");
					bhb.setVisible(true);
					p14.setVisible(false);
				}
				
			}
			
		});
		bhb.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				bh.setVisible(false);
				bhh.setVisible(false);
				bhb.setVisible(false);
				sah.add(sahh);
				f.add(sah);
				f.add(sa);
				f.add(p15);
				sa.setVisible(true);
				sah.setVisible(true);
				l1.setText("LEVEL 5: Sigma (Alpha)");
			}
			
		});
		sa.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				sahp -= 10;
				sahh.setText("HP: " + sahp);
				if(sahp == 0){
					sahh.setFont(nf3);
					sahh.setText("�������! FUCK YOU!!!!!");
					sab.setVisible(true);
					p15.setVisible(false);
				}
				
			}
			
		});
		sab.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				sa.setVisible(false);
				sah.setVisible(false);
				sab.setVisible(false);
				p1.setVisible(false);
				f.add(balp);
				f.add(balb);
				f.add(ftp);
			}
	});
		balb.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				bal.setText("��� ������: THREE HUNDRED BUCKS");
			}
			
		});
	}
}
	
